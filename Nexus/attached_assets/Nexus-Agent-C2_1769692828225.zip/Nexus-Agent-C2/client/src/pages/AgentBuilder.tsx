import { useState } from "react";
import { useScripts, useGenerateScript, useCreateScript } from "@/hooks/use-scripts";
import { Layout } from "@/components/Layout";
import { CyberCard } from "@/components/CyberCard";
import { CyberButton } from "@/components/CyberButton";
import { Bot, Save, Code2, Sparkles, AlertCircle, Copy, Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function AgentBuilder() {
  const { toast } = useToast();
  const { data: scripts = [] } = useScripts();
  const { mutate: generate, isPending: isGenerating } = useGenerateScript();
  const { mutate: save, isPending: isSaving } = useCreateScript();

  const [prompt, setPrompt] = useState("");
  const [targetOs, setTargetOs] = useState<"windows" | "android" | "linux">("windows");
  const [name, setName] = useState("");
  const [generatedCode, setGeneratedCode] = useState("");
  const [explanation, setExplanation] = useState("");
  const [hasCopied, setHasCopied] = useState(false);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || !name.trim()) return;

    generate({ prompt, targetOs, name }, {
      onSuccess: (data) => {
        setGeneratedCode(data.code);
        setExplanation(data.explanation);
        toast({ title: "Generation Complete", description: "AI has forged your tool." });
      },
      onError: (err) => {
        toast({ title: "Generation Failed", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleSave = () => {
    if (!generatedCode || !name) return;
    save({
      name,
      targetOs,
      code: generatedCode,
      description: prompt
    }, {
      onSuccess: () => {
        toast({ title: "Script Saved", description: "Added to your arsenal." });
      }
    });
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedCode);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-8rem)]">
        
        {/* Left Col: Input */}
        <div className="lg:col-span-1 space-y-6 overflow-auto">
          <CyberCard title="CONSTRUCT AGENT" icon={<Bot />}>
            <form onSubmit={handleGenerate} className="space-y-4">
               <div className="space-y-2">
                 <label className="text-xs font-mono text-primary/80 uppercase">Tool Name</label>
                 <input 
                   value={name}
                   onChange={(e) => setName(e.target.value)}
                   className="w-full cyber-input"
                   placeholder="e.g. Log Harvester"
                   required
                 />
               </div>

               <div className="space-y-2">
                 <label className="text-xs font-mono text-primary/80 uppercase">Target System</label>
                 <div className="grid grid-cols-3 gap-2">
                    {["windows", "android", "linux"].map(os => (
                      <button
                        key={os}
                        type="button"
                        onClick={() => setTargetOs(os as any)}
                        className={cn(
                          "px-2 py-2 border rounded font-mono text-xs uppercase transition-all",
                          targetOs === os 
                            ? "bg-primary text-black border-primary font-bold shadow-[0_0_10px_rgba(0,255,65,0.4)]" 
                            : "bg-transparent border-border text-muted-foreground hover:border-primary/50 hover:text-primary"
                        )}
                      >
                        {os}
                      </button>
                    ))}
                 </div>
               </div>

               <div className="space-y-2">
                 <label className="text-xs font-mono text-primary/80 uppercase">Capabilities Prompt</label>
                 <textarea 
                   value={prompt}
                   onChange={(e) => setPrompt(e.target.value)}
                   className="w-full cyber-input min-h-[150px] resize-none"
                   placeholder="Describe what this agent script should do... e.g., 'Scan /var/log for auth errors and report top 5 IPs'"
                   required
                 />
               </div>

               <CyberButton type="submit" className="w-full" isLoading={isGenerating} icon={<Sparkles className="w-4 h-4" />}>
                 GENERATE PAYLOAD
               </CyberButton>
            </form>
          </CyberCard>

          <CyberCard title="SAVED ARSENAL" icon={<Code2 />} className="max-h-[300px] overflow-hidden flex flex-col">
            <div className="overflow-y-auto flex-1 pr-2 space-y-2">
              {scripts.length === 0 && <p className="text-muted-foreground text-sm italic">No scripts archived.</p>}
              {scripts.map(script => (
                <div key={script.id} className="p-3 border border-border/50 rounded hover:border-primary/30 transition-colors bg-black/20">
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-white text-sm">{script.name}</h4>
                    <span className="text-[10px] bg-white/10 px-1 rounded uppercase text-muted-foreground">{script.targetOs}</span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 mt-1 font-mono opacity-70">
                    {script.description}
                  </p>
                </div>
              ))}
            </div>
          </CyberCard>
        </div>

        {/* Right Col: Output */}
        <div className="lg:col-span-2 flex flex-col h-full min-h-0">
           <CyberCard className="flex-1 flex flex-col p-0 overflow-hidden border-primary/20 h-full">
              <div className="p-4 border-b border-border bg-black/40 flex items-center justify-between">
                 <div className="flex items-center gap-2 text-primary font-mono text-sm">
                   <Code2 className="w-4 h-4" />
                   <span>PAYLOAD.JS</span>
                 </div>
                 <div className="flex gap-2">
                    <button 
                      onClick={copyToClipboard}
                      className="text-xs flex items-center gap-1 hover:text-primary transition-colors text-muted-foreground px-3 py-1 border border-border rounded"
                      disabled={!generatedCode}
                    >
                      {hasCopied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                      {hasCopied ? "COPIED" : "COPY"}
                    </button>
                    <CyberButton 
                      onClick={handleSave} 
                      disabled={!generatedCode || isSaving} 
                      icon={<Save className="w-3 h-3" />}
                      className="text-xs py-1 h-8"
                    >
                      SAVE
                    </CyberButton>
                 </div>
              </div>
              
              <div className="flex-1 bg-black/80 overflow-auto p-4 font-mono text-sm relative">
                {!generatedCode ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground/30 pointer-events-none">
                    <Bot className="w-24 h-24 mb-4 opacity-20" />
                    <p>AWAITING AI GENERATION...</p>
                  </div>
                ) : (
                  <pre className="text-green-400/90 whitespace-pre-wrap">
                    <code>{generatedCode}</code>
                  </pre>
                )}
              </div>

              {explanation && (
                <div className="p-4 bg-primary/5 border-t border-primary/20 text-xs font-mono text-primary/80">
                   <div className="flex items-center gap-2 mb-1 font-bold">
                     <AlertCircle className="w-3 h-3" />
                     ANALYSIS
                   </div>
                   {explanation}
                </div>
              )}
           </CyberCard>
        </div>
      </div>
    </Layout>
  );
}
